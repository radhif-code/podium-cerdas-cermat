import { useCallback, useEffect, useRef, useState } from "react";
import {
  DEFAULT_SETTINGS,
  DEFAULT_TEAMS,
  TEAM_COLORS,
  type Settings,
  type Team,
} from "@/lib/scoreboard";

const STORAGE_KEY = "gemass-scoreboard-v1";

export interface FloatingDelta {
  id: number;
  teamId: string;
  value: number;
}

interface Persisted {
  settings: Settings;
  teams: Team[];
}

function sanitizeTeams(teams: Team[]): Team[] {
  return teams.map((t) => ({
    ...t,
    score: Number.isFinite(t.score) ? Math.max(0, Math.round(t.score)) : 0,
    logo: typeof t.logo === "string" ? t.logo : null,
    color: typeof t.color === "string" ? t.color : "#f97316",
  }));
}

export function useScoreboard() {
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [teams, setTeams] = useState<Team[]>(DEFAULT_TEAMS);
  const [deltas, setDeltas] = useState<FloatingDelta[]>([]);
  const hydrated = useRef(false);
  const deltaId = useRef(0);

  // Hydrate from localStorage after first (SSR-safe) render
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Persisted> & { settings?: Record<string, unknown> };
        if (parsed.settings) {
          const merged = { ...DEFAULT_SETTINGS, ...parsed.settings } as Settings;
          // migrate the old single "increments" list into the plus buttons
          const legacy = (parsed.settings as { increments?: number[] }).increments;
          if (!Array.isArray(merged.plusValues) && Array.isArray(legacy)) {
            merged.plusValues = [...legacy, 0, 0, 0].slice(0, 4);
          }
          setSettings(merged);
        }
        if (Array.isArray(parsed.teams) && parsed.teams.length > 0) {
          setTeams(sanitizeTeams(parsed.teams));
        }
      }
    } catch {
      // corrupted storage — keep defaults
    }
    hydrated.current = true;
  }, []);

  // Persist
  useEffect(() => {
    if (!hydrated.current) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ settings, teams } satisfies Persisted));
    } catch {
      // storage full — scores still work in memory
    }
  }, [settings, teams]);

  const teamsRef = useRef(teams);
  useEffect(() => {
    teamsRef.current = teams;
  }, [teams]);

  const pushDelta = useCallback((teamId: string, value: number) => {
    const id = ++deltaId.current;
    setDeltas((d) => [...d, { id, teamId, value }]);
    window.setTimeout(() => {
      setDeltas((d) => d.filter((x) => x.id !== id));
    }, 1600);
  }, []);

  const clamp = useCallback(
    (value: number) => {
      const max = settings.maxScore ?? Number.POSITIVE_INFINITY;
      return Math.max(0, Math.min(max, Math.round(value)));
    },
    [settings.maxScore],
  );

  const adjustScore = useCallback(
    (teamId: string, delta: number) => {
      const team = teamsRef.current.find((t) => t.id === teamId);
      if (!team) return;
      const next = clamp(team.score + delta);
      const applied = next - team.score;
      if (applied === 0) return;
      setTeams((ts) => ts.map((t) => (t.id === teamId ? { ...t, score: next } : t)));
      pushDelta(teamId, applied);
    },
    [clamp, pushDelta],
  );

  const resetScore = useCallback(
    (teamId: string) => {
      setTeams((ts) =>
        ts.map((t) => {
          if (t.id !== teamId) return t;
          const next = clamp(t.initialScore);
          if (next !== t.score) pushDelta(teamId, next - t.score);
          return { ...t, score: next };
        }),
      );
    },
    [clamp, pushDelta],
  );

  const setScore = useCallback(
    (teamId: string, value: number) => {
      const team = teamsRef.current.find((t) => t.id === teamId);
      if (!team) return;
      const next = clamp(value);
      if (next === team.score) return;
      setTeams((ts) => ts.map((t) => (t.id === teamId ? { ...t, score: next } : t)));
      pushDelta(teamId, next - team.score);
    },
    [clamp, pushDelta],
  );

  const resetAllScores = useCallback(() => {
    setTeams((ts) => ts.map((t) => ({ ...t, score: clamp(t.initialScore) })));
  }, [clamp]);

  const updateTeam = useCallback((teamId: string, patch: Partial<Team>) => {
    setTeams((ts) => ts.map((t) => (t.id === teamId ? { ...t, ...patch } : t)));
  }, []);

  const addTeam = useCallback(() => {
    setTeams((ts) => {
      const id = `t${Date.now().toString(36)}${Math.floor(Math.random() * 1000)}`;
      const color = TEAM_COLORS[ts.length % TEAM_COLORS.length] ?? "#f97316";
      return [...ts, { id, name: `Tim ${ts.length + 1}`, logo: null, color, score: 0, initialScore: 0 }];
    });
  }, []);

  const removeTeam = useCallback((teamId: string) => {
    setTeams((ts) => (ts.length > 2 ? ts.filter((t) => t.id !== teamId) : ts));
  }, []);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings((s) => ({ ...s, ...patch }));
  }, []);

  const resetAll = useCallback(() => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
    setSettings(DEFAULT_SETTINGS);
    setTeams(DEFAULT_TEAMS);
  }, []);

  return {
    settings,
    teams,
    deltas,
    adjustScore,
    resetScore,
    setScore,
    resetAllScores,
    updateTeam,
    addTeam,
    removeTeam,
    updateSettings,
    resetAll,
  };
}

export type Scoreboard = ReturnType<typeof useScoreboard>;

export function rankTeams(teams: Team[]): Team[] {
  return [...teams].sort(
    (a, b) => b.score - a.score || a.name.localeCompare(b.name, "id"),
  );
}
