import { createFileRoute } from "@tanstack/react-router";
import type { CSSProperties } from "react";
import { useState } from "react";
import EventHeader from "@/components/scoreboard/EventHeader";
import Leaderboard from "@/components/scoreboard/Leaderboard";
import OperatorPanel from "@/components/scoreboard/OperatorPanel";
import SettingsPanel from "@/components/scoreboard/SettingsPanel";
import TimerPanel from "@/components/scoreboard/TimerPanel";
import { useScoreboard } from "@/hooks/use-scoreboard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GEMASS — Papan Skor Cerdas Cermat Desa Sruni" },
      {
        name: "description",
        content:
          "Papan skor realtime lomba cerdas cermat GEMA Anak Sholih Sholihah, Muda-Mudi Sruni Al-Barokah, Desa Sruni.",
      },
      { property: "og:title", content: "GEMASS — Papan Skor Cerdas Cermat Desa Sruni" },
      {
        property: "og:description",
        content:
          "Leaderboard realtime, panel operator, dan timer untuk lomba cerdas cermat GEMA Anak Sholih Sholihah, Desa Sruni.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const sb = useScoreboard();
  const [settingsOpen, setSettingsOpen] = useState(false);

  return (
    <div
      className="relative min-h-screen overflow-x-clip font-sans"
      style={{ "--theme": sb.settings.themeColor } as CSSProperties}
    >
      {/* Animated pastel gradient backdrop */}
      <div className="scene" data-variant={sb.settings.background} aria-hidden>
        <span className="blob blob-1" />
        <span className="blob blob-2" />
        <span className="blob blob-3" />
        <span className="blob blob-4" />
        <span className="blob blob-5" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 pb-20 sm:px-6">
        <EventHeader settings={sb.settings} />

        {/* Center stage: fullscreen podium */}
        <div className="mt-12">
          <Leaderboard teams={sb.teams} settings={sb.settings} deltas={sb.deltas} />
        </div>

        {/* Below the podium: operator panel + timer */}
        <div className="mx-auto mt-14 grid max-w-6xl grid-cols-1 items-start gap-8 lg:grid-cols-[minmax(380px,1fr)_400px]">
          {/* Left: operator panel */}
          <OperatorPanel
            teams={sb.teams}
            settings={sb.settings}
            deltas={sb.deltas}
            adjustScore={sb.adjustScore}
            resetScore={sb.resetScore}
            setScore={sb.setScore}
          />

          {/* Right: timer */}
          <TimerPanel />
        </div>
      </div>

      {/* Floating settings button */}
      <button
        onClick={() => setSettingsOpen(true)}
        title="Pengaturan"
        className="glass soft-pulse fixed bottom-5 right-5 z-40 grid h-14 w-14 place-items-center rounded-full text-2xl"
      >
        ⚙️
      </button>

      <SettingsPanel
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={sb.settings}
        teams={sb.teams}
        updateSettings={sb.updateSettings}
        updateTeam={sb.updateTeam}
        addTeam={sb.addTeam}
        removeTeam={sb.removeTeam}
        resetAll={sb.resetAll}
      />
    </div>
  );
}
