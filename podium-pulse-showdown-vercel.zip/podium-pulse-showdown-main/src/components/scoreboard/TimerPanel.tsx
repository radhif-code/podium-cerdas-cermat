import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

function formatTime(totalSeconds: number): { mm: string; ss: string } {
  const s = Math.max(0, totalSeconds);
  return {
    mm: String(Math.floor(s / 60)).padStart(2, "0"),
    ss: String(s % 60).padStart(2, "0"),
  };
}

const PRESETS = [1, 3, 5, 10, 15, 20];

export default function TimerPanel() {
  const [total, setTotal] = useState(300);
  const [remaining, setRemaining] = useState(300);
  const [running, setRunning] = useState(false);
  const [timeUp, setTimeUp] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const wrapRef = useRef<HTMLDivElement>(null);
  const remainingRef = useRef(remaining);
  useEffect(() => {
    remainingRef.current = remaining;
  }, [remaining]);

  const beep = useCallback(() => {
    try {
      const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new Ctx();
      [0, 0.35, 0.7].forEach((offset) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = 880;
        gain.gain.setValueAtTime(0.001, ctx.currentTime + offset);
        gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + offset + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + offset + 0.3);
        osc.connect(gain).connect(ctx.destination);
        osc.start(ctx.currentTime + offset);
        osc.stop(ctx.currentTime + offset + 0.32);
      });
      window.setTimeout(() => void ctx.close(), 1500);
    } catch {
      // audio unavailable — visual cue is enough
    }
  }, []);

  // Ticker using wall-clock so it stays accurate
  useEffect(() => {
    if (!running) return;
    const endAt = Date.now() + remainingRef.current * 1000;
    const iv = window.setInterval(() => {
      const left = Math.max(0, Math.round((endAt - Date.now()) / 1000));
      setRemaining(left);
      if (left === 0) {
        setRunning(false);
        setTimeUp(true);
        beep();
      }
    }, 200);
    return () => window.clearInterval(iv);
  }, [running, beep]);

  // Fullscreen bookkeeping
  useEffect(() => {
    const handler = () => setIsFullscreen(document.fullscreenElement === wrapRef.current);
    document.addEventListener("fullscreenchange", handler);
    return () => document.removeEventListener("fullscreenchange", handler);
  }, []);

  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else {
        await wrapRef.current?.requestFullscreen();
      }
    } catch {
      // fullscreen blocked (e.g. iframe) — ignore
    }
  };

  const adjustMinutes = (delta: number) => {
    if (running) return;
    setTimeUp(false);
    const nextTotal = Math.max(5, Math.min(120 * 60, total + delta * 60));
    setTotal(nextTotal);
    setRemaining(nextTotal);
  };

  const applyPreset = (minutes: number) => {
    if (running) return;
    setTimeUp(false);
    const nextTotal = minutes * 60;
    setTotal(nextTotal);
    setRemaining(nextTotal);
  };

  const reset = () => {
    setRunning(false);
    setTimeUp(false);
    setRemaining(total);
  };

  const toggleRun = () => {
    if (remaining === 0) {
      setRemaining(total);
      setTimeUp(false);
      setRunning(true);
      return;
    }
    setTimeUp(false);
    setRunning((r) => !r);
  };

  const { mm, ss } = formatTime(remaining);
  const progress = total > 0 ? remaining / total : 0;
  const R = 88;
  const CIRC = 2 * Math.PI * R;
  const urgent = remaining <= 30 && remaining > 0;

  const buttonBase =
    "rounded-2xl px-5 py-2.5 font-display font-bold shadow-md transition-transform duration-100 active:scale-95 disabled:opacity-40";

  return (
    <div
      ref={wrapRef}
      className={`glass rounded-3xl p-5 ${
        isFullscreen
          ? "timer-fs flex flex-col items-center justify-center gap-6 p-8"
          : ""
      }`}
    >
      <div className="flex items-center gap-3">
        <h2 className="font-display text-xl font-extrabold tracking-tight">⏱ Timer</h2>
        <span className="h-px flex-1 bg-white/70" />
        <button
          onClick={toggleFullscreen}
          title="Mode layar penuh"
          className="rounded-xl bg-white/70 px-3 py-1.5 text-sm font-bold shadow-sm transition hover:bg-white active:scale-95"
        >
          ⛶ Layar Penuh
        </button>
      </div>

      {/* Ring + digits */}
      <div className={`relative grid place-items-center ${isFullscreen ? "py-2" : "mx-auto mt-2"}`}>
        <svg
          width={isFullscreen ? "min(56vh, 56vw)" : "190"}
          height={isFullscreen ? "min(56vh, 56vw)" : "190"}
          viewBox="0 0 200 200"
          className={urgent ? "animate-pulse" : undefined}
        >
          <circle cx="100" cy="100" r={R} fill="none" stroke="oklch(1 0 0 / 70%)" strokeWidth="12" />
          <circle
            cx="100"
            cy="100"
            r={R}
            fill="none"
            stroke={timeUp ? "var(--minus)" : urgent ? "var(--minus)" : "var(--theme)"}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={CIRC}
            strokeDashoffset={CIRC * (1 - progress)}
            transform="rotate(-90 100 100)"
            style={{ transition: "stroke-dashoffset 0.3s linear" }}
          />
        </svg>
        <div className="absolute inset-0 grid place-items-center">
          {timeUp ? (
            <motion.p
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", bounce: 0.5 }}
              className="font-display text-2xl font-extrabold text-minus"
            >
              WAKTU HABIS!
            </motion.p>
          ) : (
            <p
              className={`font-display font-extrabold tabular-nums tracking-tight ${
                isFullscreen ? "text-[16vh] leading-none" : "text-5xl"
              }`}
            >
              {mm}
              <span className={running ? "" : "opacity-60"}>:</span>
              {ss}
            </p>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className={`flex items-center justify-center gap-2.5 ${isFullscreen ? "flex-wrap" : "mt-3 flex-wrap"}`}>
        <button
          onClick={toggleRun}
          className={`${buttonBase} bg-theme text-theme-foreground shadow-lg shadow-theme/30 hover:brightness-110`}
        >
          {!running && remaining === total ? "▶ Mulai" : running ? "⏸ Jeda" : "▶ Lanjut"}
        </button>
        <button
          onClick={reset}
          className={`${buttonBase} bg-white/70 text-foreground hover:bg-white`}
        >
          ⟲ Reset
        </button>
      </div>

      {/* Minute adjustment */}
      <div className={`flex flex-col items-center gap-2 ${isFullscreen ? "" : "mt-3"}`}>
        <div className="flex items-center gap-2">
          <button
            onClick={() => adjustMinutes(-5)}
            disabled={running}
            className="rounded-xl bg-white/70 px-3 py-1.5 text-sm font-bold shadow-sm transition hover:bg-white active:scale-95 disabled:opacity-40"
          >
            −5 mnt
          </button>
          <button
            onClick={() => adjustMinutes(-1)}
            disabled={running}
            className="rounded-xl bg-white/70 px-3 py-1.5 text-sm font-bold shadow-sm transition hover:bg-white active:scale-95 disabled:opacity-40"
          >
            −1
          </button>
          <span className="rounded-xl bg-white/80 px-3 py-1.5 font-display text-sm font-extrabold tabular-nums shadow-sm">
            {Math.round(total / 60)} mnt
          </span>
          <button
            onClick={() => adjustMinutes(1)}
            disabled={running}
            className="rounded-xl bg-white/70 px-3 py-1.5 text-sm font-bold shadow-sm transition hover:bg-white active:scale-95 disabled:opacity-40"
          >
            +1
          </button>
          <button
            onClick={() => adjustMinutes(5)}
            disabled={running}
            className="rounded-xl bg-white/70 px-3 py-1.5 text-sm font-bold shadow-sm transition hover:bg-white active:scale-95 disabled:opacity-40"
          >
            +5 mnt
          </button>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-1.5">
          {PRESETS.map((m) => (
            <button
              key={m}
              onClick={() => applyPreset(m)}
              disabled={running}
              className={`rounded-full px-3 py-1 text-xs font-bold shadow-sm transition active:scale-95 disabled:opacity-40 ${
                Math.round(total / 60) === m
                  ? "bg-theme text-theme-foreground"
                  : "bg-white/70 hover:bg-white"
              }`}
            >
              {m} mnt
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
