import { motion } from "framer-motion";
import type { Settings } from "@/lib/scoreboard";

const LOGOS = [
  { src: "/logos/team-ldii.png", alt: "Tim LDII" },
  { src: "/logos/gemass-logo.png", alt: "GEMASS — Gema Anak Sholih Sholihah" },
  { src: "/logos/team-ppg.png", alt: "Tim PPG" },
  { src: "/logos/event-logo.png", alt: "Muda-Mudi Sruni Al-Barokah" },
];

export default function EventHeader({ settings }: { settings: Settings }) {
  return (
    <header className="relative pt-8 text-center sm:pt-12">
      {/* All logos in one row — LDII leftmost */}
      <motion.div
        initial={{ opacity: 0, y: -14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="glass-soft mx-auto flex w-fit items-center justify-center gap-2.5 rounded-full px-4 py-2.5 sm:gap-4 sm:px-6 sm:py-3"
      >
        {LOGOS.map((logo) => (
          <span
            key={logo.alt}
            title={logo.alt}
            className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-white/80 p-1.5 shadow-md ring-2 ring-white sm:h-16 sm:w-16 sm:p-2"
          >
            <img src={logo.src} alt={logo.alt} className="max-h-full max-w-full object-contain" />
          </span>
        ))}
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.12, duration: 0.6 }}
        className="title-gradient mt-5 font-display text-5xl font-extrabold tracking-tight sm:text-6xl lg:text-7xl"
      >
        {settings.competitionName}
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.22, duration: 0.6 }}
        className="mt-2 text-sm font-semibold tracking-[0.55em] text-muted-foreground sm:text-base"
      >
        {settings.location}
      </motion.p>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.32, duration: 0.5, type: "spring", bounce: 0.4 }}
        className="mt-5 inline-flex items-center gap-2"
      >
        <span className="badge-gradient soft-pulse inline-flex items-center rounded-full px-6 py-2.5 font-display text-sm font-extrabold tracking-widest uppercase sm:text-base">
          {settings.badgeText}
        </span>
      </motion.div>
    </header>
  );
}
