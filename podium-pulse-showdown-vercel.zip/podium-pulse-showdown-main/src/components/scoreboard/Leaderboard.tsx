import { useEffect, useMemo, useRef } from "react";
import { motion } from "framer-motion";
import confetti from "canvas-confetti";
import { DeltaLayer, ScoreNumber } from "@/components/scoreboard/ScoreDisplay";
import { rankTeams, type FloatingDelta } from "@/hooks/use-scoreboard";
import { initialsOf, type Settings, type Team } from "@/lib/scoreboard";

const MEDALS: Record<number, string> = { 1: "🥇", 2: "🥈", 3: "🥉" };

function TeamAvatar({ team, size }: { team: Team; size: "sm" | "md" | "lg" }) {
  const dim =
    size === "lg" ? "h-20 w-20 sm:h-24 sm:w-24" : size === "md" ? "h-14 w-14" : "h-10 w-10";
  if (team.logo) {
    return (
      <img
        src={team.logo}
        alt={team.name}
        className={`${dim} shrink-0 rounded-full bg-white object-contain p-1 ring-2 ring-white/80 shadow-md`}
      />
    );
  }
  return (
    <div
      className={`${dim} grid shrink-0 place-items-center rounded-full font-display font-extrabold text-white shadow-md ring-2 ring-white/80 ${
        size === "lg" ? "text-3xl" : size === "sm" ? "text-sm" : "text-lg"
      }`}
      style={{ backgroundColor: team.color }}
    >
      {initialsOf(team.name)}
    </div>
  );
}

function ProgressBar({ team, denom }: { team: Team; denom: number }) {
  const pct = denom > 0 ? Math.min(100, Math.round((team.score / denom) * 100)) : 0;
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-white/70 shadow-inner">
      <motion.div
        className="h-full rounded-full"
        style={{ background: `linear-gradient(90deg, ${team.color}aa, ${team.color})` }}
        initial={false}
        animate={{ width: `${pct}%` }}
        transition={{ type: "spring", stiffness: 90, damping: 20 }}
      />
    </div>
  );
}

function PodiumCard({
  team,
  place,
  denom,
  deltas,
}: {
  team: Team;
  place: 1 | 2 | 3;
  denom: number;
  deltas: FloatingDelta[];
}) {
  const isFirst = place === 1;
  return (
    <motion.div
      layout
      transition={{ type: "spring", stiffness: 260, damping: 28 }}
      className={`glass relative flex flex-col items-center rounded-3xl ${
        isFirst
          ? "gold-glow w-[min(360px,86vw)] px-6 pb-6 pt-7 lg:w-[400px]"
          : "w-[min(180px,29vw)] px-4 pb-4 pt-5 lg:w-[270px]"
      }`}
    >
      {/* rank medal chip */}
      <span
        className={`absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-white px-2.5 py-1 shadow-lg ${
          isFirst ? "-top-4 text-2xl" : "text-lg"
        }`}
      >
        {MEDALS[place]}
      </span>

      {isFirst && (
        <span
          className="crown-float absolute -top-12 right-2 text-4xl drop-shadow-lg sm:-top-14 sm:right-4 sm:text-5xl"
          aria-hidden
        >
          👑
        </span>
      )}

      <TeamAvatar team={team} size={isFirst ? "lg" : "md"} />

      <p
        className={`mt-3 max-w-full truncate text-center font-display font-bold ${
          isFirst ? "text-xl sm:text-2xl" : "text-base sm:text-lg"
        }`}
      >
        {team.name}
      </p>

      <div className="relative">
        <DeltaLayer deltas={deltas} teamId={team.id} />
        <ScoreNumber
          value={team.score}
          className={`font-display font-extrabold ${
            isFirst ? "text-6xl sm:text-7xl" : "text-4xl sm:text-5xl"
          }`}
        />
      </div>

      <div className="mt-3 w-full">
        <ProgressBar team={team} denom={denom} />
      </div>
    </motion.div>
  );
}

function RankRow({
  team,
  place,
  denom,
  deltas,
}: {
  team: Team;
  place: number;
  denom: number;
  deltas: FloatingDelta[];
}) {
  return (
    <motion.li
      layout
      transition={{ type: "spring", stiffness: 260, damping: 28 }}
      className="glass-soft relative flex items-center gap-3 rounded-2xl px-3.5 py-3"
    >
      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/80 font-display text-sm font-extrabold text-muted-foreground shadow-sm">
        {place}
      </span>
      <TeamAvatar team={team} size="sm" />
      <div className="min-w-0 flex-1">
        <p className="truncate font-display text-sm font-bold">{team.name}</p>
        <div className="mt-1.5">
          <ProgressBar team={team} denom={denom} />
        </div>
      </div>
      <div className="relative shrink-0 pr-1">
        <DeltaLayer deltas={deltas} teamId={team.id} />
        <ScoreNumber value={team.score} className="font-display text-2xl font-extrabold" />
      </div>
    </motion.li>
  );
}

export default function Leaderboard({
  teams,
  settings,
  deltas,
}: {
  teams: Team[];
  settings: Settings;
  deltas: FloatingDelta[];
}) {
  const ranked = useMemo(() => rankTeams(teams), [teams]);
  const [first, second, third] = ranked;
  const rest = ranked.slice(3);

  const topScore = ranked[0]?.score ?? 0;
  const denom = settings.maxScore ?? Math.max(topScore, 1);

  // Celebrate whenever the leader changes (not on first load)
  const prevLeader = useRef<string | undefined>(undefined);
  useEffect(() => {
    const leaderId = ranked[0]?.id;
    if (!leaderId) return;
    if (prevLeader.current === undefined) {
      prevLeader.current = leaderId;
      return;
    }
    if (prevLeader.current !== leaderId && (ranked[0]?.score ?? 0) > 0) {
      prevLeader.current = leaderId;
      const colors = ["#ffd700", "#ff9f43", "#ff6b81", "#a29bfe", "#54e6f5", "#ffffff"];
      confetti({
        particleCount: 170,
        spread: 85,
        startVelocity: 42,
        origin: { x: 0.5, y: 0.22 },
        colors,
        disableForReducedMotion: true,
      });
      window.setTimeout(() => {
        confetti({
          particleCount: 90,
          spread: 110,
          scalar: 0.8,
          origin: { x: 0.3, y: 0.3 },
          colors,
          disableForReducedMotion: true,
        });
        confetti({
          particleCount: 90,
          spread: 110,
          scalar: 0.8,
          origin: { x: 0.7, y: 0.3 },
          colors,
          disableForReducedMotion: true,
        });
      }, 320);
    } else {
      prevLeader.current = leaderId;
    }
  }, [ranked]);

  if (!first) return null;

  return (
    <section aria-label="Papan peringkat" className="relative">
      <div className="flex items-center gap-3 px-1">
        <h2 className="font-display text-xl font-extrabold tracking-tight">🏆 Podium Peringkat</h2>
        <span className="h-px flex-1 bg-white/70" />
        <span className="rounded-full bg-white/70 px-3 py-1 text-xs font-bold text-muted-foreground shadow-sm">
          Realtime
        </span>
      </div>

      {/* Podium: 2nd left, 1st center, 3rd right */}
      <div className="mt-6 flex items-end justify-center gap-3 sm:gap-5">
        {second ? <PodiumCard team={second} place={2} denom={denom} deltas={deltas} /> : <div className="w-1" />}
        <PodiumCard team={first} place={1} denom={denom} deltas={deltas} />
        {third ? <PodiumCard team={third} place={3} denom={denom} deltas={deltas} /> : <div className="w-1" />}
      </div>

      {/* Remaining teams */}
      {rest.length > 0 && (
        <ul className="mx-auto mt-6 max-w-3xl space-y-3">
          {rest.map((team, i) => (
            <RankRow key={team.id} team={team} place={i + 4} denom={denom} deltas={deltas} />
          ))}
        </ul>
      )}
    </section>
  );
}
