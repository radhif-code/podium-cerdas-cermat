Taruh 4 file logo di folder ini (nama harus persis):
  event-logo.png   (logo Muda-Mudi Sruni Al-Barokah)
  gemass-logo.png  (logo GEMASS)
  team-ldii.png    (logo Tim LDII)
  team-ppg.png     (logo Tim PPG)
